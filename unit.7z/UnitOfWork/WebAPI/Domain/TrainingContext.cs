﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Domain
{
    public class TrainingContext: DbContext
    {
        public  TrainingContext(DbContextOptions options):base(options)
        {
        }
        public DbSet<MD_Customer> MD_Customer { get; set; }
        public DbSet<MD_CustomerType> MD_CustomerType { get; set; }
        public DbSet<AM_User> AM_User { get; set; }
        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<MD_Customer>()
        //        .HasKey(t => t.CustomerID);
        //    modelBuilder.Entity<MD_CustomerType>()
        //        .HasKey(t => t.CustomerTypeID);
        //    modelBuilder.Entity<AM_User>()
        //        .HasKey(t => t.UserID);
                
        //}
        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            foreach (var entry in ChangeTracker.Entries<BaseEntity>())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.Entity.UpdatedDate = DateTime.Now; ;
                        break;

                    case EntityState.Modified:
                        entry.Entity.UpdatedDate = DateTime.Now; ;
                        break;
                }
            }

            var result = await base.SaveChangesAsync(cancellationToken);
            return result;
        }
    }
}
