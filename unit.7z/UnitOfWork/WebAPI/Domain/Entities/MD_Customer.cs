﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public partial class MD_Customer:BaseEntity
    {
        [Key]
        public int CustomerID { get; set; }
        public string CustomerCode { get; set; }
        public string FullName { get; set; }
        public string  FirstName { get; set; }
        public string LastName { get; set; }
        public string TaxCode { get; set; }
        public string Address { get; set; }
        public int? CustomerTypeID { get; set; }
        public virtual MD_CustomerType CustomerType { get; set; }

    }
}
