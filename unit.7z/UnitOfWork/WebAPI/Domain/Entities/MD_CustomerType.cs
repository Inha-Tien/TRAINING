﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public partial class MD_CustomerType:BaseEntity
    {
        public MD_CustomerType()
        {
            Customers = new List<MD_Customer>();
        }
        [Key]
        public int CustomerTypeID { get; set; }
        public string CustomerTypeCode { get; set; }
        public string CustomerTypeName { get; set; }
        public virtual ICollection<MD_Customer> Customers { get; set; }
    }
}
