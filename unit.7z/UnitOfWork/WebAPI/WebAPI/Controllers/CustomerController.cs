﻿using DataAccessEF.Interfaces;
using Domain;
using Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using WebAPI.Model;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerController : ControllerBase
    {

        private readonly IUnitOfWork unitOfWork;

        public CustomerController(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IEnumerable<MD_Customer> GetAllCustomer()
        {
            return unitOfWork.RepositoryAsync<MD_Customer>().GetAll();
        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> AddCustomer(CustomerRequest customer)
        {
            var mc = new MD_Customer()
            {
                CustomerCode = customer.Code,
                FullName = customer.Name,
                CustomerTypeID = 1
            };
            unitOfWork.RepositoryAsync<MD_Customer>().Add(mc);
            unitOfWork.Save();
            return Ok();
        }
    }
}
